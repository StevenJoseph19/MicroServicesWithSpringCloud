package com.microservices.ribbontime.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonTimeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
