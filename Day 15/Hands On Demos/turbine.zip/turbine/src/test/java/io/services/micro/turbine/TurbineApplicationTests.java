package io.services.micro.turbine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurbineApplicationTests {

	@Test
	void contextLoads() {
	}

}
